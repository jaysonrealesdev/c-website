# Offline.js Simulate UI Plug-In

[Offline.js](https://github.com/hubspot/offline) plug-in that allows you to test how your pages respond to different connectivity states without having to use brute-force methods to disable your actual connectivity.

For installation and usage instructions as well as a working demo, please visit [the website](http://craigshoemaker.github.io/offlinejs-simulate-ui/).
